﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiniProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int[] randomNumbers;
        double interval = 0.1;
        double X = 1.1; //1.1 to 2 max
        int[] count_mistakes;
        int[] answer;
        int[] N;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void intialize()
        {
            N = new int[3];
            N[0] = 10;
            N[1] = 15;
            N[2] = 13;
        }
        private void Show_Fixed_Array_Click(object sender, RoutedEventArgs e)
        {
            intialize();
            Random random = new Random();
            int mistake = 0;
            int j_for_mistake = 0;
            string numbers_Fixed;
            int i= 0;
            for (int j=0;j<N.Length;j++)
            {
                count_mistakes = new int[9];
                while (X <= 2)
                {
                    double size_str = N[j] * X;
                    int size = int.Parse(size_str.ToString());
                    randomNumbers = new int[size];
                    for (int count = 0; count < size; count++)
                    {
                        randomNumbers[count] = random.Next(10000, 20000);
                    }
                    answer = new int[size];
                    for (i = 0; i < size; i++)
                    {
                        answer[i] = -1;
                    }
                    for (i = 0; i < size; i++)
                    {
                        int number_to_enter = randomNumbers[i];
                        mistake = enterNewNumber(answer, number_to_enter, size, mistake);
                        count_mistakes[j_for_mistake] += mistake;
                        mistake = 0;
                    }
                    j_for_mistake += 1;
                    X += interval;
                }
                FixedArray.Visibility = Visibility.Visible;
                numbers_Fixed = "Trial number" + (j+1).ToString() + ": {";
                for (int r = 0; r < count_mistakes.Length - 1; r++)
                {
                    numbers_Fixed += "mistakes on attemp " + (r + 1).ToString() + " is: ";
                    numbers_Fixed += count_mistakes[r].ToString() + ",";
                }
                numbers_Fixed += "mistakes on attemp " + (count_mistakes.Length + 1).ToString() + " is: " + count_mistakes[count_mistakes.Length - 1];
                numbers_Fixed += "}" + Environment.NewLine;
                FixedArray.Text += numbers_Fixed;
                X = 1.1;
                j_for_mistake = 0;
            }
        }

        private int enterNewNumber(int[] answer,int number,int size,int mistake)
        {
            int position = number%size;
            int pos = int.Parse(position.ToString());
            while(answer[pos] != -1)
            {
                mistake += 1;
                pos = (pos + 1) % size; // for circle
            }
            answer[pos] = number;
            return mistake;
        }
    }
}